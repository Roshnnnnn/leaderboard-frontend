import { useState, useEffect } from 'react'
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline'
import axios from 'axios'

function App() {
  const [users, setUsers] = useState([])
  const [searchId, setSearchId] = useState('')
  const [filterType, setFilterType] = useState('Day')
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  const fetchLeaderboard = async (filter = null, userId = null) => {
    try {
      const params = new URLSearchParams()
      if (filter) params.append('filter', filter)
      if (userId) params.append('userId', userId)
      
      const response = await axios.get(`http://localhost:5000/api/leaderboard?${params}`)
      setUsers(response.data)
    } catch (error) {
      console.error('Error fetching leaderboard:', error)
    }
  }

  const handleRecalculate = async () => {
    try {
      await axios.post('http://localhost:5000/api/recalculate')
      fetchLeaderboard(filterType)
    } catch (error) {
      console.error('Error recalculating:', error)
    }
  }

  const handleSearch = (e) => {
    setSearchId(e.target.value)
    if (e.target.value) {
      fetchLeaderboard(null, e.target.value)
    } else {
      fetchLeaderboard(filterType)
    }
  }

  const handleFilterChange = (type) => {
    setFilterType(type)
    setIsFilterOpen(false)
    fetchLeaderboard(type)
  }

  useEffect(() => {
    fetchLeaderboard(filterType)
  }, [])

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header Section */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={handleRecalculate}
            className="bg-gray-700 px-4 py-2 rounded-md hover:bg-gray-600"
          >
            Recalculate
          </button>
          
          {/* Search Section */}
          <div className="flex gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="User ID"
                value={searchId}
                onChange={handleSearch}
                className="bg-gray-800 px-4 py-2 rounded-md pl-10 focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
              <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-2.5 text-gray-400" />
            </div>
            <div className="relative">
              <button 
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="bg-gray-700 px-4 py-2 rounded-md hover:bg-gray-600"
              >
                Filter
              </button>
              {isFilterOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg">
                  {['Day', 'Month', 'Year'].map((type) => (
                    <button
                      key={type}
                      onClick={() => handleFilterChange(type)}
                      className="block w-full text-left px-4 py-2 hover:bg-gray-700"
                    >
                      {type}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Filter Type Display */}
        <div className="mb-6">
          <div className="text-sm text-gray-400">
            Sort by {filterType} ▼
          </div>
        </div>

        {/* Leaderboard Table */}
        <div className="space-y-2">
          {users.map((user) => (
            <div
              key={user.id}
              className="bg-gray-800 p-4 rounded-lg flex justify-between items-center"
            >
              <div className="flex gap-4">
                <span className="text-gray-400">{user.id}</span>
                <span>{user.full_name}</span>
              </div>
              <div className="flex gap-4">
                <span>{user.total_points}</span>
                <span className="text-gray-400">#{user.rank}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default App